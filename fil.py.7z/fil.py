import os

def split_file(input_file, chunk_size_mb=25):
    # تحديد حجم الشريحة بالبايت
    chunk_size = chunk_size_mb * 1024 * 1024
    # فتح الملف النصي الكبير
    with open(input_file, 'r', encoding='utf-8') as file:
        # إعداد المتغيرات
        part_number = 1
        current_chunk = []
        current_chunk_size = 0
        
        for line in file:
            # حجم السطر الحالي بالبايت
            line_size = len(line.encode('utf-8'))
            
            # التحقق إذا كان حجم الشريحة الحالي سيتجاوز الحجم المحدد
            if current_chunk_size + line_size > chunk_size:
                # كتابة الشريحة إلى ملف جديد
                with open(f'fox{part_number}.txt', 'w', encoding='utf-8') as chunk_file:
                    chunk_file.writelines(current_chunk)
                
                # التبديل إلى الشريحة الجديدة
                part_number += 1
                current_chunk = []
                current_chunk_size = 0
            
            # إضافة السطر الحالي إلى الشريحة
            current_chunk.append(line)
            current_chunk_size += line_size
        
        # كتابة الشريحة الأخيرة إلى ملف
        if current_chunk:
            with open(f'fox{part_number}.txt', 'w', encoding='utf-8') as chunk_file:
                chunk_file.writelines(current_chunk)

# استدعاء الدالة مع اسم الملف الكبير
split_file('fox.txt')
